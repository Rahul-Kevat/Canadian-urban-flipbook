<?php

// BEGIN iThemes Security - Do not modify or remove this line
// iThemes Security Config Details: 2
define( 'DISALLOW_FILE_EDIT', true ); // Disable File Editor - Security > Settings > WordPress Tweaks > File Editor
// END iThemes Security - Do not modify or remove this line
define( 'WP_CACHE', false ); // Added by WP Rocket

/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'team3_canadian_urban_flipbook' );

/** MySQL database username */
define( 'DB_USER', 'team3_canadian_urban_flipbook' );

/** MySQL database password */
define( 'DB_PASSWORD', 'FmK81}YJ@H+~' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'BDI/dDe8ED&-h-*.RBZo,4a*M<eWR^h^:lZAN`ZP0*)(!-kQ(D88U+E=w&@9kE3~' );
define( 'SECURE_AUTH_KEY',  '6TvWn, DyB(yR6|L#l8l9JgpzJ<T6ts6r)5) `?<QQ`x)i;G5tgwe@Z3?McvOU4{' );
define( 'LOGGED_IN_KEY',    '_{IhZ){uFKldG`~<2r(fbT]LnAVQ2Y,aKDbPK!s8{DlA<,>/X70G oNn*{Vv<pcI' );
define( 'NONCE_KEY',        '@#Oee>wD49B?N:>Xn7qHgK/~Hs~%:/cl07*EZtX6Z|yc}w2s6+`2c{czjVz:@L`0' );
define( 'AUTH_SALT',        '|P&rW6M/)3.A/+yzyt<xNoBPA{sB^LV]h[8qmXJil&P</FrX93($n,DrIQqej0vv' );
define( 'SECURE_AUTH_SALT', '!xzkIsh y#F{T4HU!.xp-{:H@48&#ds,9N_8H&D|o  mHVYT5AO_OU3fy]dE{_+!' );
define( 'LOGGED_IN_SALT',   'a2d~?w_N; )5dimy2c:lEhpG#_c$ns#4m*3!mYB>?u3R{T}qPrrd<$S3(M8C/ij5' );
define( 'NONCE_SALT',       'yn6@Q<jw7~ox6O:9&yY0lL=s:|R i;>;6_:nr%^yD^W6%E&+M/t02=3&TxLnG.XY' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
